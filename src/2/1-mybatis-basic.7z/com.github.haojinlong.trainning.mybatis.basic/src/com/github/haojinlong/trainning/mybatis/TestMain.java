/**
 * # TestMain.java -- (2014年6月29日)
 * 作者：郝金隆
 * 联系方式：haojinlong@189.cn
 */
package com.github.haojinlong.trainning.mybatis;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.github.haojinlong.trainning.mybatis.entity.Users;

/**
 * @author 郝金隆
 * 
 */
public class TestMain {
	static Logger logger = LoggerFactory.getLogger(TestMain.class);

	public static void main(String[] args) {
		testUpdate();
	}

	public static void testSelectOne() {
		String resource = "mybatis-config.xml";
		SqlSessionFactory sqlSessionFactory = null;
		try {
			InputStream inputStream = Resources.getResourceAsStream(resource);
			sqlSessionFactory = new SqlSessionFactoryBuilder()
					.build(inputStream);
		} catch (IOException e) {
			e.printStackTrace();
		}
		SqlSession sqlSession = sqlSessionFactory.openSession();

		Users users = sqlSession
				.selectOne(
						"com.github.haojinlong.trainning.mybatis.mapper.UsersMapper.selectById",
						1);
		logger.debug("the value of users: {}", users);
		sqlSession.close();
	}

	public static void testListAll() {
		String resource = "mybatis-config.xml";
		SqlSessionFactory sqlSessionFactory = null;
		try {
			InputStream inputStream = Resources.getResourceAsStream(resource);
			sqlSessionFactory = new SqlSessionFactoryBuilder()
					.build(inputStream);
		} catch (IOException e) {
			e.printStackTrace();
		}
		SqlSession sqlSession = sqlSessionFactory.openSession();

		List<Users> users = sqlSession
				.selectList("com.github.haojinlong.trainning.mybatis.mapper.UsersMapper.listAll");
		logger.debug("the value of users: {}", users);
		sqlSession.close();
	}

	public static void testDelete() {
		String resource = "mybatis-config.xml";
		SqlSessionFactory sqlSessionFactory = null;
		try {
			InputStream inputStream = Resources.getResourceAsStream(resource);
			sqlSessionFactory = new SqlSessionFactoryBuilder()
					.build(inputStream);
		} catch (IOException e) {
			e.printStackTrace();
		}
		SqlSession sqlSession = sqlSessionFactory.openSession();

		int count = sqlSession
				.delete("com.github.haojinlong.trainning.mybatis.mapper.UsersMapper.delete",
						3);
		logger.debug("the delete count: {}", count);
		sqlSession.close();
	}

	public static void testInsert() {
		String resource = "mybatis-config.xml";
		SqlSessionFactory sqlSessionFactory = null;
		try {
			InputStream inputStream = Resources.getResourceAsStream(resource);
			sqlSessionFactory = new SqlSessionFactoryBuilder()
					.build(inputStream);
		} catch (IOException e) {
			e.printStackTrace();
		}
		SqlSession sqlSession = sqlSessionFactory.openSession();

		Users users = new Users();
		users.setName("hjl");
		users.setPasswd("hjl");
		users.setAge(20);
		sqlSession
				.insert("com.github.haojinlong.trainning.mybatis.mapper.UsersMapper.insert",
						users);
		logger.debug("the value of users: {}", users);

		sqlSession.close();
	}

	public static void testUpdate() {
		String resource = "mybatis-config.xml";
		SqlSessionFactory sqlSessionFactory = null;
		try {
			InputStream inputStream = Resources.getResourceAsStream(resource);
			sqlSessionFactory = new SqlSessionFactoryBuilder()
					.build(inputStream);
		} catch (IOException e) {
			e.printStackTrace();
		}
		SqlSession sqlSession = sqlSessionFactory.openSession();

		Users users = sqlSession
				.selectOne(
						"com.github.haojinlong.trainning.mybatis.mapper.UsersMapper.selectById",
						1);
		users.setName("haojinlong2");
		sqlSession
				.update("com.github.haojinlong.trainning.mybatis.mapper.UsersMapper.update",
						users);
		logger.debug("the value of users: {}", users);
		sqlSession.close();
	}
}
