
-- 创建库表
drop table if exists users; 
create table users(
	id integer not null primary key auto_increment comment '自增长ID',
	name char(20) comment '姓名',
	passwd char(20) comment '密码',
	age integer comment '年龄'
) comment '测试表';

-- 创建测试数据
insert into users(name, passwd, age) 
	values('haojinlong', 'haojinlong', 30);
insert into users(name, passwd, age) 
	values('jucky', 'jucky', 18);
insert into users(name, passwd, age) 
	values('william', 'william', 30);
insert into users(name, passwd, age) 
	values('john', 'john', 30);
