/**
 * # UsersMapper.java -- (2014年6月29日)
 * 作者：郝金隆
 * 联系方式：haojinlong@189.cn
 */
package com.github.haojinlong.trainning.mybatis.mapper;

import java.util.List;
import com.github.haojinlong.trainning.mybatis.entity.Users;

/**
 * @author 郝金隆
 */
public interface UsersMapper {
	public Users selectById(int id);
	public List<Users> listAll();
	public int insert(Users users);
	public int delete(int id);
	public int update(Users users);
}
