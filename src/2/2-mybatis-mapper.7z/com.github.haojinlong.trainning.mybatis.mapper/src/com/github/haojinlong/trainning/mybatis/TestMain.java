/**
 * # TestMain.java -- (2014年6月29日)
 * 作者：郝金隆
 * 联系方式：haojinlong@189.cn
 */
package com.github.haojinlong.trainning.mybatis;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.github.haojinlong.trainning.mybatis.entity.Users;
import com.github.haojinlong.trainning.mybatis.mapper.UsersMapper;

/**
 * @author 郝金隆
 * 
 */
public class TestMain {
	static Logger logger = LoggerFactory.getLogger(TestMain.class);

	public static void main(String[] args) {
		testListAll();
		testInsert();
		testDelete();
		testUpdate();
	}

	public static void testSelectOne() {
		String resource = "mybatis-config.xml";
		SqlSessionFactory sqlSessionFactory = null;
		try {
			InputStream inputStream = Resources.getResourceAsStream(resource);
			sqlSessionFactory = new SqlSessionFactoryBuilder()
					.build(inputStream);
		} catch (IOException e) {
			e.printStackTrace();
		}
		SqlSession sqlSession = sqlSessionFactory.openSession();
		UsersMapper usersMapper = sqlSession.getMapper(UsersMapper.class);
		Users users = usersMapper.selectById(1);

		logger.debug("the value of users: {}", users);
		sqlSession.close();
	}

	public static void testListAll() {
		String resource = "mybatis-config.xml";
		SqlSessionFactory sqlSessionFactory = null;
		try {
			InputStream inputStream = Resources.getResourceAsStream(resource);
			sqlSessionFactory = new SqlSessionFactoryBuilder()
					.build(inputStream);
		} catch (IOException e) {
			e.printStackTrace();
		}
		SqlSession sqlSession = sqlSessionFactory.openSession();
		UsersMapper usersMapper = sqlSession.getMapper(UsersMapper.class);

		List<Users> users = usersMapper.listAll();
		logger.debug("the value of users: {}", users);
		sqlSession.close();
	}

	public static void testDelete() {
		String resource = "mybatis-config.xml";
		SqlSessionFactory sqlSessionFactory = null;
		try {
			InputStream inputStream = Resources.getResourceAsStream(resource);
			sqlSessionFactory = new SqlSessionFactoryBuilder()
					.build(inputStream);
		} catch (IOException e) {
			e.printStackTrace();
		}
		SqlSession sqlSession = sqlSessionFactory.openSession();
		UsersMapper usersMapper = sqlSession.getMapper(UsersMapper.class);
		int count = usersMapper.delete(3);
		logger.debug("the delete count: {}", count);
		sqlSession.close();
	}

	public static void testInsert() {
		String resource = "mybatis-config.xml";
		SqlSessionFactory sqlSessionFactory = null;
		try {
			InputStream inputStream = Resources.getResourceAsStream(resource);
			sqlSessionFactory = new SqlSessionFactoryBuilder()
					.build(inputStream);
		} catch (IOException e) {
			e.printStackTrace();
		}
		SqlSession sqlSession = sqlSessionFactory.openSession();
		UsersMapper usersMapper = sqlSession.getMapper(UsersMapper.class);
		Users users = new Users();
		users.setName("hjl");
		users.setPasswd("hjl");
		users.setAge(20);
		usersMapper.insert(users);
		logger.debug("the value of users: {}", users);

		sqlSession.close();
	}

	public static void testUpdate() {
		String resource = "mybatis-config.xml";
		SqlSessionFactory sqlSessionFactory = null;
		try {
			InputStream inputStream = Resources.getResourceAsStream(resource);
			sqlSessionFactory = new SqlSessionFactoryBuilder()
					.build(inputStream);
		} catch (IOException e) {
			e.printStackTrace();
		}
		SqlSession sqlSession = sqlSessionFactory.openSession();
		UsersMapper usersMapper = sqlSession.getMapper(UsersMapper.class);
		Users users = usersMapper.selectById(1);
		users.setName("haojinlong2");
		usersMapper.update(users);
		logger.debug("the value of users: {}", users);
		sqlSession.close();
	}
}
