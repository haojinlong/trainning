/**
 * # LogTest2.java -- 2014年6月26日
 * 作者：郝金隆
 * 联系方式：haojinlong@189.cn
 */
package com.github.haojinlong.trainning.slf4j.jcl.logback.pkg2;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * @author 郝金隆
 * @since：2014年6月26日 下午9:11:31
 */
public class LogTest2 {
	static Log log = LogFactory.getLog(LogTest2.class);

	public static void test() {
		if (log.isDebugEnabled()) {
			log.debug("this is debug in pkg2!");
		}

		if (log.isErrorEnabled()) {
			log.error("this is error in pkg2!");
		}
	}

}
