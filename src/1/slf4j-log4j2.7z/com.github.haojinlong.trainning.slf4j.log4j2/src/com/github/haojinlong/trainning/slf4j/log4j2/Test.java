/**
 * # Test.java -- 2014年6月26日
 * 作者：郝金隆
 * 联系方式：haojinlong@189.cn
 */
package com.github.haojinlong.trainning.slf4j.log4j2;

import com.github.haojinlong.trainning.slf4j.log4j2.pkg1.LogTest1;
import com.github.haojinlong.trainning.slf4j.log4j2.pkg2.LogTest2;

/**
 * @author 郝金隆
 * @since：2014年6月26日 下午9:13:59
 */
public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		for (int i = 0; i < 1000; i++) {
			LogTest1.test();
			LogTest2.test();
		}
	}

}
