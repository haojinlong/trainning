/**
 * # LogTest2.java -- 2014年6月26日
 * 作者：郝金隆
 * 联系方式：haojinlong@189.cn
 */
package com.github.haojinlong.trainning.slf4j.log4j2.pkg2;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author 郝金隆
 * @since：2014年6月26日 下午9:11:31
 */
public class LogTest2 {
	static Logger logger = LoggerFactory.getLogger(LogTest2.class);

	public static void test() {
		if (logger.isDebugEnabled()) {
			logger.debug("this is debug in pkg2!");
		}

		if (logger.isErrorEnabled()) {
			logger.error("this is error in pkg2!");
		}
	}

}
