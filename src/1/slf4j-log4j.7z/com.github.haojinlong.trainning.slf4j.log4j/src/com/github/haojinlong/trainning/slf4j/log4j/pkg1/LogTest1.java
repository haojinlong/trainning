/**
 * # LogTest1.java -- 2014年6月26日
 * 作者：郝金隆
 * 联系方式：haojinlong@189.cn
 */
package com.github.haojinlong.trainning.slf4j.log4j.pkg1;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * 此类用于进行commons-logging和log4j的测试
 * 
 * @author 郝金隆
 * @since：2014年6月26日 下午8:44:30
 */
public class LogTest1 {

	static Logger logger = LoggerFactory.getLogger(LogTest1.class);

	public static void test() {
		if (logger.isDebugEnabled()) {
			logger.debug("this is debug in pkg1!");
		}

		if (logger.isErrorEnabled()) {
			logger.error("this is error in pkg1!");
		}
	}

}
