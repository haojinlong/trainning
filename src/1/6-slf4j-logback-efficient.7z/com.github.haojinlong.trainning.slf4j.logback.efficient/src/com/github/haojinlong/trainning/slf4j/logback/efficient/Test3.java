/**
 * # Test3.java -- (2014年6月27日)
 * 作者：郝金隆
 * 联系方式：haojinlong@189.cn
 */
package com.github.haojinlong.trainning.slf4j.logback.efficient;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author 郝金隆
 * 
 */
public class Test3 {
	static Logger logger = LoggerFactory.getLogger(Test3.class);

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String sayHello = "hello";
		String name = "Haojinlong";

		long beginTM = System.currentTimeMillis();
		for (int i = 0; i <= 1000000; i++) {
			if (logger.isDebugEnabled()) {
				logger.debug(sayHello + " " + name + "!");
			}
		}
		long endTM = System.currentTimeMillis();
		System.out.println(endTM - beginTM);
	}
}
