/**
 * # TestMain.java -- (2014年6月27日)
 * 作者：郝金隆
 * 联系方式：haojinlong@189.cn
 */
package com.github.haojinlong.trainning.slf4j.logback.lang3;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author 郝金隆
 * 
 */
public class TestMain {
	static Logger logger = LoggerFactory.getLogger(TestMain.class);

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Person p = new Person();
		logger.debug("the value of person: {}", p);
	}
}
