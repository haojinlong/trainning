/**
 * # TestMain.java -- (2014年7月19日)
 * 作者：郝金隆
 * 联系方式：haojinlong@189.cn
 */
package com.github.haojinlong.trainning.spring.anno.basic;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.github.haojinlong.trainning.spring.anno.basic.inter.Person;
import com.github.haojinlong.trainning.spring.anno.basic.inter.SayHello;

/**
 * @author 郝金隆
 * 
 */
public class TestMain {
	static Logger logger = LoggerFactory.getLogger(TestMain.class);

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext(
				"BasicApplicationContext.xml");
		SayHello sayHello = applicationContext.getBean("mySayHello",
				SayHello.class);
		logger.debug("say hello: {}", sayHello.sayHello());

		Person person = applicationContext.getBean("hPerson", Person.class);
		logger.debug("person name: {}", person.getName());
	}
}
