/**
 * # MySayHello.java -- (2014年7月19日)
 * 作者：郝金隆
 * 联系方式：haojinlong@189.cn
 */
package com.github.haojinlong.trainning.spring.anno.basic.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.haojinlong.trainning.spring.anno.basic.inter.Person;
import com.github.haojinlong.trainning.spring.anno.basic.inter.SayHello;

/**
 * @author 郝金隆
 * 
 */
@Service
public class MySayHello implements SayHello {
	static Logger logger = LoggerFactory.getLogger(MySayHello.class);

	@Autowired
	private Person person;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.github.haojinlong.trainning.spring.anno.basic.inter.SayHello#sayHello
	 * ()
	 */
	@Override
	public String sayHello() {
		return "Hello, " + person.getName() + "!";
	}
}
