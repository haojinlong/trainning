/**
 * # SayHello.java -- (2014年7月19日)
 * 作者：郝金隆
 * 联系方式：haojinlong@189.cn
 */
package com.github.haojinlong.trainning.spring.anno.basic.inter;


/**
 * @author 郝金隆
 * 
 */
public interface SayHello {
	public String sayHello();
}
