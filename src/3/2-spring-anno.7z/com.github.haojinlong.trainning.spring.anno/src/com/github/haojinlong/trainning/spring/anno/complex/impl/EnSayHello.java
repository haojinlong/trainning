/**
 * # EnSayHello.java -- (2014年7月20日)
 * 作者：郝金隆
 * 联系方式：haojinlong@189.cn
 */
package com.github.haojinlong.trainning.spring.anno.complex.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.github.haojinlong.trainning.spring.anno.complex.inter.Person;
import com.github.haojinlong.trainning.spring.anno.complex.inter.SayHello;

/**
 * English sayHello
 * 
 * @author 郝金隆
 * 
 */
@Component
public class EnSayHello implements SayHello {
	static Logger logger = LoggerFactory.getLogger(EnSayHello.class);

	@Autowired
	@Qualifier("jamesPerson")
	private Person person;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.github.haojinlong.trainning.spring.anno.complex.inter.SayHello#sayHello
	 * ()
	 */
	@Override
	public String sayHello() {
		return "Hello, " + person.getName() + "!";
	}
}
