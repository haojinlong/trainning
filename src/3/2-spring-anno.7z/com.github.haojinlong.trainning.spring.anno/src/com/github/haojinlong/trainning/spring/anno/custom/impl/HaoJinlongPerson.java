/**
 * # HaoJinlongPerson.java -- (2014年7月19日)
 * 作者：郝金隆
 * 联系方式：haojinlong@189.cn
 */
package com.github.haojinlong.trainning.spring.anno.custom.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.github.haojinlong.trainning.spring.anno.custom.inter.Person;

/**
 * @author 郝金隆
 * 
 */
@Component("hPerson")  // 可以替换为Service/Controller，效果一样
public class HaoJinlongPerson implements Person {
	static Logger logger = LoggerFactory.getLogger(HaoJinlongPerson.class);

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.github.haojinlong.trainning.spring.anno.basic.inter.Person#getName()
	 */
	@Override
	public String getName() {
		return "Hao Jinlong";
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.github.haojinlong.trainning.spring.anno.basic.inter.Person#getAge()
	 */
	@Override
	public int getAge() {
		return 30;
	}
}
