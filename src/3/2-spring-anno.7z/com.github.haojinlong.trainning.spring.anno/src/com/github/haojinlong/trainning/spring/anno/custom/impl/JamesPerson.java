/**
 * # JamesPerson.java -- (2014年7月19日)
 * 作者：郝金隆
 * 联系方式：haojinlong@189.cn
 */
package com.github.haojinlong.trainning.spring.anno.custom.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.github.haojinlong.trainning.spring.anno.custom.inter.Person;

/**
 * @author 郝金隆
 * 
 */
@Component
public class JamesPerson implements Person {
	static Logger logger = LoggerFactory.getLogger(JamesPerson.class);

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.github.haojinlong.trainning.spring.anno.custom.inter.Person#getName()
	 */
	@Override
	public String getName() {
		return "James";
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.github.haojinlong.trainning.spring.anno.custom.inter.Person#getAge()
	 */
	@Override
	public int getAge() {
		return 40;
	}
}
