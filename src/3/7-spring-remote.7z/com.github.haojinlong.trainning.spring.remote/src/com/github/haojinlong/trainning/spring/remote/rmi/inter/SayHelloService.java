/**
 * # SayHelloService.java -- (2014年7月20日)
 * 作者：郝金隆
 * 联系方式：haojinlong@189.cn
 */
package com.github.haojinlong.trainning.spring.remote.rmi.inter;

import com.github.haojinlong.trainning.spring.remote.rmi.entity.Person;

/**
 * @author 郝金隆
 * 
 */
public interface SayHelloService {

	public String sayHello(Person person);

}
