/**
 * # MySayHelloService.java -- (2014年7月20日)
 * 作者：郝金隆
 * 联系方式：haojinlong@189.cn
 */
package com.github.haojinlong.trainning.spring.remote.rmi.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.github.haojinlong.trainning.spring.remote.rmi.entity.Person;
import com.github.haojinlong.trainning.spring.remote.rmi.inter.SayHelloService;

/**
 * @author 郝金隆
 * 
 */
@Service
public class MySayHelloService implements SayHelloService {
	static Logger logger = LoggerFactory.getLogger(MySayHelloService.class);

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.github.haojinlong.trainning.spring.remote.rmi.inter.SayHelloService
	 * #sayHello
	 * (com.github.haojinlong.trainning.spring.remote.rmi.entity.Person)
	 */
	@Override
	public String sayHello(Person person) {
		if (person != null && person.getName() != null) {
			return "Hello, " + person.getName() + "!";
		}
		return "Hello!";
	}
}
