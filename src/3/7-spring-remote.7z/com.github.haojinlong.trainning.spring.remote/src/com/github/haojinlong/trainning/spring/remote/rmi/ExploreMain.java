/**
 * # ExploreMain.java -- (2014年7月20日)
 * 作者：郝金隆
 * 联系方式：haojinlong@189.cn
 */
package com.github.haojinlong.trainning.spring.remote.rmi;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * @author 郝金隆
 * 
 */
public class ExploreMain {
	static Logger logger = LoggerFactory.getLogger(ExploreMain.class);

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext(
				"RmiExploreApplicationContext.xml");
	}
}
