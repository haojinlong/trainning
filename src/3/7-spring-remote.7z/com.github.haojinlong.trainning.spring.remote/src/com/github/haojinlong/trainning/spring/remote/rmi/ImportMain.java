/**
 * # ImportMain.java -- (2014年7月20日)
 * 作者：郝金隆
 * 联系方式：haojinlong@189.cn
 */
package com.github.haojinlong.trainning.spring.remote.rmi;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.github.haojinlong.trainning.spring.remote.rmi.entity.Person;
import com.github.haojinlong.trainning.spring.remote.rmi.inter.SayHelloService;

/**
 * @author 郝金隆
 * 
 */
public class ImportMain {
	static Logger logger = LoggerFactory.getLogger(ImportMain.class);

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Person person = new Person();
		person.setName("Haojinlong");
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext(
				"RmiImportApplicationContext.xml");
		SayHelloService sayHelloService = applicationContext
				.getBean(SayHelloService.class);
		logger.debug("say hello: {}", sayHelloService.sayHello(person));
	}
}
