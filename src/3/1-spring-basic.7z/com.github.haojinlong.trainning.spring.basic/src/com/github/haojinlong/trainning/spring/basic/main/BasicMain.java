/**
 * # BasicMain.java -- (2014年7月18日)
 * 作者：郝金隆
 * 联系方式：haojinlong@189.cn
 */
package com.github.haojinlong.trainning.spring.basic.main;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.github.haojinlong.trainning.spring.basic.inter.Person;
import com.github.haojinlong.trainning.spring.basic.inter.SayHello;

/**
 * @author 郝金隆
 * 
 */
public class BasicMain {
	static Logger logger = LoggerFactory.getLogger(BasicMain.class);

	public static void main(String[] args) {
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext(
				"BasicApplicationContext.xml");
		Person hPerson = applicationContext.getBean("haoJinlongPerson",
				Person.class);
		logger.debug("hPerson name: {}", hPerson.getName());
		Person jPerson = applicationContext
				.getBean("jamesPerson", Person.class);
		logger.debug("jPerson name: {}", jPerson.getName());

		SayHello sayHello = applicationContext.getBean(SayHello.class);
		logger.debug("sayHello: {}", sayHello.sayHelo());
	}
}
