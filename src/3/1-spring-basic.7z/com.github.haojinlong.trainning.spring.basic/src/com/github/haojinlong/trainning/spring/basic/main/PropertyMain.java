/**
 * # PropertyMain.java -- (2014年7月18日)
 * 作者：郝金隆
 * 联系方式：haojinlong@189.cn
 */
package com.github.haojinlong.trainning.spring.basic.main;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.github.haojinlong.trainning.spring.basic.inter.Person;
import com.github.haojinlong.trainning.spring.basic.inter.SayHello;

/**
 * @author 郝金隆
 * 
 */
public class PropertyMain {
	static Logger logger = LoggerFactory.getLogger(PropertyMain.class);

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext(
				"PropertyApplicationContext.xml");
		Person jPerson = applicationContext.getBean("jPerson", Person.class);
		logger.debug("jPerson name: {}", jPerson.getName());
		Person hPerson = applicationContext.getBean("hPerson", Person.class);
		logger.debug("hPerson name: {}", hPerson.getName());
		SayHello sayHello = applicationContext.getBean(SayHello.class);
		logger.debug("say hello: {}", sayHello.sayHelo());
	}
}
