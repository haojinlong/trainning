/**
 * # DefaultPerson.java -- (2014年7月18日)
 * 作者：郝金隆
 * 联系方式：haojinlong@189.cn
 */
package com.github.haojinlong.trainning.spring.basic.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.github.haojinlong.trainning.spring.basic.inter.Person;

/**
 * @author 郝金隆
 * 
 */
public class DefaultPerson implements Person {
	static Logger logger = LoggerFactory.getLogger(DefaultPerson.class);

	private String name;

	private int age;

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the age
	 */
	public int getAge() {
		return age;
	}

	/**
	 * @param age
	 *            the age to set
	 */
	public void setAge(int age) {
		this.age = age;
	}

}
