/**
 * # DefaultSayHello.java -- (2014年7月18日)
 * 作者：郝金隆
 * 联系方式：haojinlong@189.cn
 */
package com.github.haojinlong.trainning.spring.basic.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.github.haojinlong.trainning.spring.basic.inter.Person;
import com.github.haojinlong.trainning.spring.basic.inter.SayHello;

/**
 * @author 郝金隆
 * 
 */
public class DefaultSayHello implements SayHello {
	static Logger logger = LoggerFactory.getLogger(DefaultSayHello.class);

	private Person person;

	/**
	 * @return the person
	 */
	public Person getPerson() {
		return person;
	}

	/**
	 * @param person
	 *            the person to set
	 */
	public void setPerson(Person person) {
		this.person = person;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.github.haojinlong.trainning.spring.basic.inter.SayHello#sayHelo()
	 */
	@Override
	public String sayHelo() {
		return "Hello, " + person.getName() + "!";
	}
}
