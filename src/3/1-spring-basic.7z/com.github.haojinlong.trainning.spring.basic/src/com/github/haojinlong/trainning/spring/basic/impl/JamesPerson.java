/**
 * # JamesPerson.java -- (2014年7月18日)
 * 作者：郝金隆
 * 联系方式：haojinlong@189.cn
 */
package com.github.haojinlong.trainning.spring.basic.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.github.haojinlong.trainning.spring.basic.inter.Person;

/**
 * @author 郝金隆
 * 
 */
public class JamesPerson implements Person {
	static Logger logger = LoggerFactory.getLogger(JamesPerson.class);

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.github.haojinlong.trainning.spring.basic.inter.Person#getName()
	 */
	@Override
	public String getName() {
		return "James";
	}

	/* (non-Javadoc)
	 * @see com.github.haojinlong.trainning.spring.basic.inter.Person#getAge()
	 */
	@Override
	public int getAge() {
		return 40;
	}
}
