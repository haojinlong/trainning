/**
 * # ConstructMain.java -- (2014年7月18日)
 * 作者：郝金隆
 * 联系方式：haojinlong@189.cn
 */
package com.github.haojinlong.trainning.spring.basic.main;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.github.haojinlong.trainning.spring.basic.inter.Person;
import com.github.haojinlong.trainning.spring.basic.inter.SayHello;

/**
 * @author 郝金隆
 * 
 */
public class ConstructMain {
	static Logger logger = LoggerFactory.getLogger(ConstructMain.class);

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext(
				"ConstructArgApplicationContext.xml");
		Person person = applicationContext.getBean(Person.class);
		logger.debug("person name: {}", person.getName());
		SayHello sayHello = applicationContext.getBean(SayHello.class);
		logger.debug("say hello: {}", sayHello.sayHelo());
	}
}
